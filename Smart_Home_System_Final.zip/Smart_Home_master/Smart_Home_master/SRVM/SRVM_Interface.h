/*
 * SRVM_Interface.h
 *
 *  Created on: Sep 21, 2023
 *      Author: alaae
 */

#ifndef SRVM_INTERFACE_H_
#define SRVM_INTERFACE_H_

void SRVM_voidOn (u8 Copy_u8Angle);
void SRVM_voidOff(void);


#endif /* SRVM_INTERFACE_H_ */
