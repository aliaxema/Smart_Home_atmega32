/*
 * GI_Priv.h
 *
 * Created: 11-Sep-23 11:52:56 AM
 *  Author: lenovo
 */ 


#ifndef GI_PRIV_H_
#define GI_PRIV_H_


#define SREG (*(volatile uint8*)0x5F)
#define I		7	


#endif /* GI_PRIV_H_ */