/*
 * GI_Inter.h
 *
 * Created: 11-Sep-23 11:52:38 AM
 *  Author: lenovo
 */ 


#ifndef GI_INTER_H_
#define GI_INTER_H_

#include "../STD_TYPES.h"
#include "../BIT_MATH.h"

#include "GI_Priv.h"



void GI_Enable(void);
void GI_Disable(void);



#endif /* GI_INTER_H_ */