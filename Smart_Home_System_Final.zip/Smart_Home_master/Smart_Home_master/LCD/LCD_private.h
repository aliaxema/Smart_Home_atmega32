/*
 * LCD_private.h
 *
 * Created: 10-Sep-23 1:44:27 PM
 *  Author: lenovo
 */ 


#ifndef LCD_PRIVATE_H_
#define LCD_PRIVATE_H_
#include "../STD_TYPES.h"
#include "../BIT_MATH.h"
static void Write_Half_Port(uint8 Value);

#endif /* LCD_PRIVATE_H_ */