/*
 * SPI_Config.h
 *
 *  Created on: Sep 23, 2023
 *      Author: alaae
 */

#ifndef SPI_CONFIG_H_
#define SPI_CONFIG_H_

#define MOSI   Pin_B5
#define MISO   Pin_B6
#define SCK    Pin_B7
#define SS     Pin_B4







#endif /* SPI_CONFIG_H_ */
